'use client';

import TaskList from '@/components/TaskList';

export default function TaskView() {
  return <TaskList />;
} 